package university.jala.institutional.aplicacioncompras;

public class Main {
   public static void main(String[] args) {
       Menu menu = new Menu();
       menu.iniciar();
   }
}

